import javax.swing.JTabbedPane;

public class CanvasGroup extends JTabbedPane{

    CanvasGroup() {
    }
}